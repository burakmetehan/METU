# TESTER-for-CENG140-THE3-for-Sections-1-2

To use the tester: You need to use a Linux system, or WSL. Make sure you put your c file(named as the3.c) and these files in the same directory. Run test.py.

Note: Inputs and expected outputs for function 6 and 7 are changed.

UPDATE: New inputs are added. You can use them by replacing inputs and expected folders with the folders in case7000.zip.

IMPORTANT NOTE: This tester does not check whether you freed the memory after some operations or not, so please check them manually.

Good luck...
